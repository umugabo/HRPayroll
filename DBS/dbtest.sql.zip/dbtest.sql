-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 29, 2016 at 05:29 PM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `phone` int(11) NOT NULL,
  `title` varchar(25) NOT NULL,
  `department` varchar(25) NOT NULL,
  `level` text NOT NULL,
  `image` blob NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `admin`
--


-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userfname` text NOT NULL,
  `userlname` text NOT NULL,
  `usersector` varchar(20) NOT NULL,
  `usercell` varchar(15) NOT NULL,
  `current_date` date NOT NULL,
  `question` text NOT NULL,
  `phone_nbr` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone_nbr` (`phone_nbr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `appointment`
--


-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `question_id` int(11) NOT NULL AUTO_INCREMENT,
  `userfname` text NOT NULL,
  `userlname` text NOT NULL,
  `userid` int(17) NOT NULL,
  `userphone` int(11) NOT NULL,
  `usersector` varchar(25) NOT NULL,
  `usercell` varchar(32) NOT NULL,
  `s_question` text NOT NULL,
  `conclution` text NOT NULL,
  `nb` text NOT NULL,
  `l_fname` text NOT NULL,
  `l_lname` text NOT NULL,
  `l_title` varchar(12) NOT NULL,
  `lr_phone` int(11) NOT NULL,
  `received_date` date NOT NULL,
  PRIMARY KEY (`question_id`),
  UNIQUE KEY `userphone` (`userphone`,`lr_phone`),
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `question`
--


-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first` int(30) NOT NULL,
  `last` int(30) NOT NULL,
  `phone` int(11) NOT NULL,
  `title` varchar(30) NOT NULL,
  `department` varchar(30) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`,`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sector`
--


-- --------------------------------------------------------

--
-- Table structure for table `tata`
--

CREATE TABLE IF NOT EXISTS `tata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` text NOT NULL,
  `last_name` text NOT NULL,
  `phone_number` int(11) NOT NULL,
  `date` date NOT NULL,
  `sector` varchar(14) NOT NULL,
  `cell` varchar(17) NOT NULL,
  `username` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(50) NOT NULL,
  `picture` blob NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone_number` (`phone_number`),
  UNIQUE KEY `phone_number_2` (`phone_number`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `username_2` (`username`),
  UNIQUE KEY `username_3` (`username`),
  UNIQUE KEY `phone_number_3` (`phone_number`,`username`,`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `tata`
--

INSERT INTO `tata` (`id`, `first_name`, `last_name`, `phone_number`, `date`, `sector`, `cell`, `username`, `email`, `password`, `picture`) VALUES
(50, 'dusabeyezu', 'jeremy', 728581813, '2003-08-04', 'gatumba', 'cyome', 'jeremy', 'jeremydusabe@gmail.com', 'abcd', 0x47524143452032303135313231345f3137313034332e6a7067),
(51, 'mugabo', 'mutsinzi', 728324851, '1997-08-30', 'gatumba', 'cyome', 'chrimu', 'chrimu25@gmail.com', '1234', 0x4453435f303039382e4a5047),
(56, 'dfgsdf', 'sdfgsdfg', 1534534, '1999-02-02', 'sdfgdg', 'sdfgsdfg', 'sdfgfdggdfgsdfg', 'sdfdf@gmail.com', 'weweesdfgsdfgfdg', 0x6e65772061666963682e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `phone` int(10) NOT NULL,
  `date_of_birth` date NOT NULL,
  `sector` text NOT NULL,
  `cell` text NOT NULL,
  `username` varchar(40) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `image` longblob NOT NULL,
  PRIMARY KEY (`id`,`username`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `phone`, `date_of_birth`, `sector`, `cell`, `username`, `email`, `password`, `image`) VALUES
(1, '', '', 0, '0000-00-00', '', '', 'chrimu', 'CHRIMU25@GMAIL.COM', 'e10adc3949ba59abbe56e057f20f883e', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` text NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(31, '', '', ''),
(30, 'noah', 'noahniyobu@gmail.com', 'asdfgh');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
